---
name: Question
about: Ask a question about Lark or request help
title: ''
labels: question
assignees: ''

---

**What is your question?**

Try to be accurate and concise.

**If you're having trouble with your code or grammar**

Provide a small script that encapsulates your issue.

Explain what you're trying to do, and what is obstructing your progress.
